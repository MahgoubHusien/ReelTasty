// src/blob-polyfill.d.ts
declare module 'blob-polyfill' {
    export const Blob: typeof globalThis.Blob;
  }
  