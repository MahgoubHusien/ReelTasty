import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import TikAPI from 'tikapi';
import { Pool } from 'pg';

dotenv.config();

const api = TikAPI(process.env.TIKAPI_KEY);

const s3 = new S3Client({
  credentials: {
    accessKeyId: process.env.ACCESS_KEY_ID || '',
    secretAccessKey: process.env.SECRET_ACCESS_KEY || '',
  },
  region: process.env.REGION || '',
});

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

interface VideoMetadata {
  videoId: string;
  author: string;
  description: string;
  hashtags: string;
  s3Url: string;
  avatarLargeUrl: string;
  stats: {
    playCount: number;
    shareCount: number;
    commentCount: number;
    diggCount: number;
  };
}

const storeVideoMetadataInDB = async (videoMetadata: VideoMetadata) => {
  try {
    console.log(`Checking if video ${videoMetadata.videoId} exists in DB...`);
    const existingVideo = await pool.query(
      'SELECT video_id FROM tiktok_videos WHERE video_id = $1',
      [videoMetadata.videoId]
    );

    if (existingVideo.rowCount ?? 0 > 0) {
      console.log(`Video ${videoMetadata.videoId} already exists in DB. Skipping insertion.`);
      return;
    }

    console.log(`Inserting video metadata for ${videoMetadata.videoId} into DB...`);
    const query = `
      INSERT INTO tiktok_videos 
      (video_id, author, description, hashtags, s3_url, avatar_large_url, play_count, share_count, comment_count, digg_count) 
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
    `;
    const values = [
      videoMetadata.videoId,
      videoMetadata.author,
      videoMetadata.description,
      videoMetadata.hashtags,
      videoMetadata.s3Url,
      videoMetadata.avatarLargeUrl,
      videoMetadata.stats.playCount,
      videoMetadata.stats.shareCount,
      videoMetadata.stats.commentCount,
      videoMetadata.stats.diggCount,
    ];

    await pool.query(query, values);
    console.log(`Video metadata for ${videoMetadata.videoId} successfully stored in DB.`);
  } catch (err) {
    console.error(`Error storing video metadata for ${videoMetadata.videoId}:`, err);
  }
};

const uploadVideoToS3 = async (filePath: string, videoId: string): Promise<string> => {
  try {
    console.log(`Reading video file from path: ${filePath}`);
    const fileContent = fs.readFileSync(filePath);
    const fileName = `${videoId}.mp4`;

    if (!process.env.S3_BUCKET_NAME) {
      throw new Error('S3_BUCKET_NAME is not defined in environment variables');
    }

    const s3Params = {
      Bucket: process.env.S3_BUCKET_NAME,
      Key: fileName,
      Body: fileContent,
      ContentType: 'video/mp4',
    };

    console.log(`Uploading video ${fileName} to S3 bucket: ${process.env.S3_BUCKET_NAME}`);
    const command = new PutObjectCommand(s3Params);
    await s3.send(command);

    const s3Url = `https://${process.env.S3_BUCKET_NAME}.s3.amazonaws.com/${fileName}`;
    console.log(`Video ${fileName} successfully uploaded to S3. URL: ${s3Url}`);
    return s3Url;
  } catch (err) {
    console.error(`Error uploading video ${videoId} to S3:`, err);
    throw err;
  }
};

export const processHashtag = async (hashtag: string) => {
  try {
    console.log(`Starting to process videos for hashtag: ${hashtag}`);
    let response = await api.public.hashtag({ name: hashtag });

    if (!response?.json) {
      throw new Error('No response from TikAPI.');
    }

    const hashtagId = response.json.challengeInfo.challenge.id;
    console.log(`Hashtag ID: ${hashtagId}`);
    
    response = await api.public.hashtag({ id: hashtagId });

    while (response) {
      const videos = response?.json?.itemList || [];
      console.log(`Found ${videos.length} videos for hashtag ${hashtag}.`);

      for (const item of videos) {
        console.log(`Processing video with ID: ${item.id}`);
        const description = item.desc.toLowerCase();

        const videoMetadata: VideoMetadata = {
          videoId: item.id,
          author: item.author.nickname,
          description: item.desc,
          hashtags: item.challengeInfoList?.map((challenge: { challengeName: string }) => challenge.challengeName).join(', ') || '',
          s3Url: '',
          avatarLargeUrl: item.author.avatarLarger,
          stats: {
            playCount: item.stats.playCount,
            shareCount: item.stats.shareCount,
            commentCount: item.stats.commentCount,
            diggCount: item.stats.diggCount,
          },
        };

        const downloadAddr = item.video.playAddr;  // Corrected field
        const filePath = path.join('/tmp', `${videoMetadata.videoId}.mp4`);

        console.log(`Downloading video from: ${downloadAddr} to ${filePath}`);
        if (response.saveVideo) {
          await response.saveVideo(downloadAddr, filePath);

          console.log(`Uploading video ${videoMetadata.videoId} to S3...`);
          videoMetadata.s3Url = await uploadVideoToS3(filePath, videoMetadata.videoId);
          console.log(`Storing video metadata for ${videoMetadata.videoId} in DB...`);
          await storeVideoMetadataInDB(videoMetadata);

          if (fs.existsSync(filePath)) {
            console.log(`Deleting local video file: ${filePath}`);
            fs.unlinkSync(filePath);
          }
        }
      }

      if (response.nextItems) {
        console.log('Fetching next batch of videos...');
        response = await response.nextItems();
      } else {
        console.log('No more videos to process for hashtag.');
        break;
      }
    }
  } catch (err) {
    console.error(`Error processing videos for hashtag ${hashtag}:`, err);
  }
};

export const processVideo = async (videoId: string) => {
  try {
    console.log(`Processing video with ID: ${videoId}`);
    const videoResponse = await api.public.video({ id: videoId });
    if (!videoResponse || !videoResponse.json) {
      throw new Error('No video data received from TikAPI.');
    }

    const item = videoResponse.json.itemInfo.itemStruct;
    console.log(`Processing video: ${item.id}`);

    const videoMetadata: VideoMetadata = {
      videoId: item.id,
      author: item.author.nickname,
      description: item.desc,
      hashtags: item.challengeInfoList?.map((challenge: { challengeName: string }) => challenge.challengeName).join(', ') || '',
      s3Url: '',
      avatarLargeUrl: item.author.avatarLarger,
      stats: {
        playCount: item.stats.playCount,
        shareCount: item.stats.shareCount,
        commentCount: item.stats.commentCount,
        diggCount: item.stats.diggCount,
      },
    };

    const downloadAddr = item.video.playAddr; // Corrected field
    const filePath = path.join('/tmp', `${videoMetadata.videoId}.mp4`);

    console.log(`Downloading video from: ${downloadAddr} to ${filePath}`);
    if (videoResponse.saveVideo) {
      await videoResponse.saveVideo(downloadAddr, filePath);

      console.log(`Uploading video ${videoMetadata.videoId} to S3...`);
      videoMetadata.s3Url = await uploadVideoToS3(filePath, videoMetadata.videoId);
      console.log(`Storing video metadata for ${videoMetadata.videoId} in DB...`);
      await storeVideoMetadataInDB(videoMetadata);

      if (fs.existsSync(filePath)) {
        console.log(`Deleting local video file: ${filePath}`);
        fs.unlinkSync(filePath);
      }

      return videoMetadata;
    }
  } catch (error) {
    console.error(`Error processing video with ID ${videoId}:`, error);
    throw new Error(`Error processing video with ID ${videoId}`);
  }
};
