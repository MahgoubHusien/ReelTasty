declare module 'node-cron';
